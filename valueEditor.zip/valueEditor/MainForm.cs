﻿using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using System.Collections.Generic;
using System.IO;

namespace ValueEditor
{
    public partial class MainForm : Form
    {
        public static CustomRichTextBox NameBox { get; private set; }
        public static CustomRichTextBox ValueBox { get; private set; }

        private FileHelper file;
        private string filePath;

        public MainForm()
        {
            InitializeComponent();
            this.Text = "ValueEditor";
            this.customRichTextBox1.OtherTextBox = this.customRichTextBox2;
            this.customRichTextBox2.OtherTextBox = this.customRichTextBox1;
            NameBox = this.customRichTextBox1;
            ValueBox = this.customRichTextBox2;
            file = new FileHelper();
            IntiEncoding();
        }

        private void IntiEncoding()
        {
            var encodings = (new Dictionary<string, Encoding> { { "ANSI", Encoding.Default }/*, { "ASCII", Encoding.ASCII } */})
            .Concat(
                new string[] { "utf-8", "GB18030"/*, "gb2312"*/, "big5", "shift_jis" }
                .Select(name => Encoding.GetEncodings().FirstOrDefault(en => en.Name == name))
                .ToDictionary(en => en.DisplayName, en => en.GetEncoding())
            );
            foreach (var en in encodings)
            {
                var item = new ToolStripMenuItem(en.Key);
                item.Click += (s, e) =>
                {
                    Settings.Encoding = en.Value;
                    if (!string.IsNullOrEmpty(filePath))
                        this.InvokeSync(() =>
                        {
                            file.Read(filePath);
                            //nameBox.Focus();
                        });
                };
                this.encoding_toolStrip.DropDownItems.Add(item);
            }
        }

        public void LoadFromContents()
        {
            Settings.TextBoxSync = false;
            NameBox.Text = string.Join("\r\n", file.Contents.Select(en => en.Name));
            ValueBox.Text = string.Join("\r\n", file.Contents.Select(en => en.Value));
            Settings.TextBoxSync = true;

            //NameBox.Select(0, 0);
            //ValueBox.Select(0, 0);
            NameBox.Focus();
        }

        public void SaveToContents()
        {
            for (int i = 0; i < file.Contents.Count - 1; i++)
            {
                var content = file.Contents[i];
                //content.Name = nameBox.Lines[i];
                //content.Value = valueBox.Lines[i];
            }
        }

        private void open_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            this.Focus();
            this.Text = "ValueEditor - " + this.openFileDialog1.SafeFileName;
            filePath = this.openFileDialog1.FileName;
            this.InvokeSync(() =>
            {
                file.Read(filePath);
                LoadFromContents();
            });
        }
        private void exit_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void save_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(filePath))
                saveFileDialog1.ShowDialog();
            else
                this.InvokeSync(() =>
                {
                    file.Save(filePath);
                });
        }

        private void close_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            filePath = "";
            file.Contents.Clear();
            this.Text = "ValueEditor";
            NameBox.Text = "";
            ValueBox.Text = "";
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            String str = "ValueEditor   v0.12\rby NiceNight\r2018-8-19";
            MessageBox.Show(str);
        }

        private void comment_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings.ShowComment = !Settings.ShowComment;
            this.comment_ToolStripMenuItem.Text = Settings.ShowComment ? "隐藏注释行" : "显示注释行";
        }

        private void blank_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings.ShowBlank = !Settings.ShowBlank;
            this.blank_ToolStripMenuItem.Text = Settings.ShowBlank ? "隐藏空白行" : "显示空白行";
        }

        private void indent_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings.ShowIndent = !Settings.ShowIndent;
            this.indent_ToolStripMenuItem.Text = Settings.ShowIndent ? "隐藏缩进" : "显示缩进";
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            filePath = saveFileDialog1.FileName;
            this.Text = "ValueEditor - " + new FileInfo(filePath).Name;
            this.InvokeSync(() =>
            {
                file.Save(filePath);
            });
        }

        private void new_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Text = "ValueEditor - new file";
            filePath = "";
            file.Contents.Clear();
            NameBox.Text = "";
            ValueBox.Text = "";
        }
    }
}
