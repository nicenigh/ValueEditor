﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ValueEditor
{
    public partial class CustomRichTextBox : System.Windows.Forms.RichTextBox
    {
        public bool Sync
        {
            get => SyncScrolll & SyncReturn & SyncSelect;
            set { SyncScrolll = value; SyncReturn = value; SyncSelect = value; }
        }

        //public List<Content> Contents { get; set; } = new List<Content>();

        public bool ShowLineNo { get; set; } = true;

        private bool SyncScrolll { get; set; } = true;

        private bool SyncReturn { get; set; } = true;

        private bool SyncSelect { get; set; } = true;


        public RichTextBox TextBox { get => this.richTextBox1; }
        public CustomRichTextBox OtherTextBox { get; set; } = null;

        #region override
        public new bool Multiline { get => TextBox.Multiline; set => TextBox.Multiline = value; }
        public new int MaxLength { get => TextBox.MaxLength; set => TextBox.MaxLength = value; }
        public new Font Font { get => TextBox.Font; set => TextBox.Font = value; }
        public new Color ForeColor { get => TextBox.ForeColor; set => TextBox.ForeColor = value; }
        public new int TextLength { get => TextBox.TextLength; }
        public new string Text { get => TextBox.Text; set => TextBox.Text = value; }
        public new string[] Lines { get => TextBox.Lines; set => TextBox.Lines = value; }
        public new string SelectedText { get => TextBox.SelectedText; set => TextBox.SelectedText = value; }
        public new int SelectionStart { get => TextBox.SelectionStart; set => TextBox.SelectionStart = value; }
        public new int SelectionLength { get => TextBox.SelectionLength; set => TextBox.SelectionLength = value; }
        public new Color SelectionBackColor { get => TextBox.SelectionBackColor; set => TextBox.SelectionBackColor = value; }
        public new void Select(int start, int length) { TextBox.Select(start, length); }
        public new void SelectAll() { TextBox.SelectAll(); }
        public new void Undo() { TextBox.Undo(); }
        public new void Redo() { TextBox.Redo(); }
        public new int GetCharIndexFromPosition(Point pt) { return TextBox.GetCharIndexFromPosition(pt); }
        public new int GetLineFromCharIndex(int index) { return TextBox.GetLineFromCharIndex(index); }
        public new Point GetPositionFromCharIndex(int index) { return TextBox.GetPositionFromCharIndex(index); }
        public new char GetCharFromPosition(Point pt) { return TextBox.GetCharFromPosition(pt); }
        public new int GetFirstCharIndexFromLine(int lineNumber) { return TextBox.GetFirstCharIndexFromLine(lineNumber); }
        public new int GetFirstCharIndexOfCurrentLine() { return TextBox.GetFirstCharIndexOfCurrentLine(); }
        public new void ScrollToCaret() { TextBox.ScrollToCaret(); }
        //public new event EventHandler VScroll { add => TextBox.VScroll += value; remove => TextBox.VScroll -= value; }
        //public new event MouseEventHandler MouseClick { add => TextBox.MouseClick += value; remove => TextBox.MouseClick -= value; }
        //public new event EventHandler SelectionChanged { add => TextBox.SelectionChanged += value; remove => TextBox.SelectionChanged -= value; }
        //public new event EventHandler Click { add => TextBox.Click += value; remove => TextBox.Click -= value; }
        //public new event EventHandler GotFocus { add => TextBox.GotFocus += value; remove => TextBox.GotFocus -= value; }
        //public new event EventHandler LostFocus { add => TextBox.LostFocus += value; remove => TextBox.LostFocus -= value; }
        //public new event EventHandler Enter { add => TextBox.Enter += value; remove => TextBox.Enter -= value; }
        //public new event EventHandler Leave { add => TextBox.Leave += value; remove => TextBox.Leave -= value; }

        public new bool Focused { get => TextBox.Focused && (OtherTextBox ?? throw new Exception("OtherTextBox Undefined")) != null; }
        #endregion
        public CustomRichTextBox()
        {
            InitializeComponent();
            this.ScrollBars = RichTextBoxScrollBars.None;
            this.Enter += (s, e) => { TextBox.Focus(); };
            this.GotFocus += (s, e) => { TextBox.Focus(); };
            TextBox.SelectionChanged += new System.EventHandler(richTextBox_SelectionChanged);
            TextBox.VScroll += new System.EventHandler(richTextBox_VScroll);
            TextBox.TextChanged += new System.EventHandler(richTextBox_TextChanged);
            TextBox.Enter += new System.EventHandler(richTextBox_Enter);
            TextBox.Leave += new System.EventHandler(richTextBox_Leave);
            TextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(richTextBox_KeyDown);
            TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(richTextBox_KeyPress);
            TextBox.Resize += new System.EventHandler(richTextBox_Resize);
        }


        #region 显示行号
        private int firstLine = -1;
        private int lastLine = -1;
        private void richTextBox_Resize(object sender, EventArgs e)
        {
            if (ShowLineNo)
                this.InvokeSync(DrawLineNo);
        }
        private void DrawLineNo()
        {
            //获得当前坐标信息
            Point p = new Point(0, 0);
            int crntFirstIndex = TextBox.GetCharIndexFromPosition(p);
            int crntFirstLine = TextBox.GetLineFromCharIndex(crntFirstIndex);
            Point crntFirstPos = TextBox.GetPositionFromCharIndex(crntFirstIndex);

            p.Y += TextBox.Height;
            int crntLastIndex = TextBox.GetCharIndexFromPosition(p);
            int crntLastLine = TextBox.GetLineFromCharIndex(crntLastIndex);
            if (TextBox.Lines.Length > 0 && TextBox.Lines[TextBox.Lines.Length - 1].Length == 0)
            {
                crntLastLine += 1;
                crntLastIndex = TextBox.GetFirstCharIndexFromLine(crntLastLine);
            }
            Point crntLastPos = TextBox.GetPositionFromCharIndex(crntLastIndex);

            if (firstLine == crntFirstLine && lastLine == crntLastLine)
                return;

            //准备画图
            Graphics g = panel1.CreateGraphics();
            Font font = new Font(TextBox.Font, TextBox.Font.Style);
            SolidBrush brush = new SolidBrush(Color.RoyalBlue);

            //刷新画布
            Rectangle rect = panel1.ClientRectangle;
            brush.Color = panel1.BackColor;
            g.FillRectangle(brush, 0, 0, panel1.ClientRectangle.Width, panel1.ClientRectangle.Height);
            brush.Color = Color.RoyalBlue;

            //绘制行号
            int lineSpace = 0;
            if (crntFirstLine != crntLastLine)
            {
                lineSpace = (crntLastPos.Y - crntFirstPos.Y) / (crntLastLine - crntFirstLine);
            }
            else
            {
                lineSpace = Convert.ToInt32(this.TextBox.Font.Size * 1.6f);
            }
            int brushX = panel1.ClientRectangle.Width - Convert.ToInt32(font.Size * 4);
            int brushY = crntLastPos.Y + Convert.ToInt32(font.Size * 0.21f);
            for (int i = crntLastLine; i >= 0; i--)
            {
                int bit = Convert.ToInt32(Math.Floor(Math.Log10((i + 1))));
                string no = new string(' ', bit > 4 ? 0 : 4 - bit) + (i + 1).ToString();
                g.DrawString(no, font, brush, brushX, brushY);
                brushY -= lineSpace;
            }
            g.Dispose();
            font.Dispose();
            brush.Dispose();
            firstLine = crntFirstLine; lastLine = crntLastLine;
        }
        #endregion

        #region 同步滚动
        private void richTextBox_VScroll(object sender, EventArgs e)
        {
            if (ShowLineNo)
                this.InvokeSync(DrawLineNo);
            if (Focused && SyncScrolll)
                this.InvokeSync(OtherTextBox.Scroll);
        }

        private void Scroll()
        {
            try
            {
                Point p = new Point(0, 0);
                int start = OtherTextBox.GetCharIndexFromPosition(p);
                int line = OtherTextBox.GetLineFromCharIndex(start);
                int nextLineStart = OtherTextBox.GetFirstCharIndexFromLine(line + 1);
                Point nextLinePoint = OtherTextBox.GetPositionFromCharIndex(nextLineStart);
                if (nextLinePoint.Y < 10)
                    line += 1;
                int currStart = TextBox.GetCharIndexFromPosition(p);
                int currLine = TextBox.GetLineFromCharIndex(currStart);
                int scrollStart = TextBox.GetFirstCharIndexFromLine(line);
                Point currPoint = TextBox.GetPositionFromCharIndex(scrollStart);
                if (currLine != line || currPoint.Y != 0)
                {
                    TextBox.SelectionStart = scrollStart;
                    TextBox.ScrollToCaret();
                }
            }
            catch { }
        }
        #endregion

        #region 同步选取
        private int colorLine = -1;

        private void richTextBox_Leave(object sender, EventArgs e)
        {
            if (colorLine > 0)
                this.InvokeSync(CleanColor);
        }
        private void richTextBox_Enter(object sender, EventArgs e)
        {
            if (colorLine > 0)
                this.InvokeSync(CleanColor);
        }
        private void richTextBox_SelectionChanged(object sender, EventArgs e)
        {
            if (Focused && SyncSelect)
                this.InvokeSync(() => { SetColor(); OtherTextBox.SetColor(); });
        }

        private void SetColor()
        {
            try
            {
                int backStart = TextBox.SelectionStart;
                int backLenght = TextBox.SelectionLength;
                int line;
                if (Focused)
                    line = TextBox.GetLineFromCharIndex(TextBox.SelectionStart);
                else
                    line = OtherTextBox.GetLineFromCharIndex(OtherTextBox.SelectionStart);
                if (line == colorLine) return;
                SyncSelect = false;
                if (colorLine > -1) CleanColor();
                int start = TextBox.GetFirstCharIndexFromLine(line);
                int lenght = TextBox.Lines[line].Length;
                TextBox.Select(start, lenght);
                if (Focused)
                    TextBox.SelectionBackColor = Color.SkyBlue;
                else
                    TextBox.SelectionBackColor = Color.Gold;
                colorLine = line;
                TextBox.Select(backStart, backLenght);
            }
            catch { }
            SyncSelect = true;
            Scroll();
        }

        private void CleanColor()
        {
            try
            {
                if (colorLine > -1)
                {
                    SyncSelect = false;
                    int backStart = TextBox.SelectionStart;
                    int backLenght = TextBox.SelectionLength;
                    int start = TextBox.GetFirstCharIndexFromLine(colorLine);
                    int lenght = TextBox.Lines[colorLine].Length;
                    TextBox.Select(start, lenght);
                    TextBox.SelectionBackColor = TextBox.BackColor;
                    TextBox.Select(backStart, backLenght);
                    colorLine = -1;
                }
            }
            catch { }
            SyncSelect = true;
            //Scroll();
        }
        #endregion

        #region 同步换行
        private int lines = 0;
        private bool keyPressing = false;
        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            if (ShowLineNo)
                this.InvokeSync(DrawLineNo);
            if (!keyPressing)
                lines = TextBox.Lines.Length;
        }
        private void richTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            keyPressing = true;
        }
        private void richTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Focused && SyncSelect)
                this.InvokeSync(() => { ChangeLines(e.KeyChar); });
            keyPressing = false;
        }

        private void ChangeLines(char key)
        {
            try
            {
                if (key == 26)
                    OtherTextBox.Undo();
                int nlines = TextBox.Lines.Length;
                if (nlines != lines)
                {
                    if (key == '\r' || key == '\n')
                    {
                        int line = TextBox.GetLineFromCharIndex(TextBox.SelectionStart);
                        int start = OtherTextBox.GetFirstCharIndexFromLine(line);
                        if (OtherTextBox.TextLength > 0 && start > -1)
                            OtherTextBox.Text = OtherTextBox.Text.Insert(start, "\r\n");
                        else
                            OtherTextBox.Text += "\r\n";

                    }
                    else if (key == '\b')
                    {
                        int line = TextBox.GetLineFromCharIndex(TextBox.SelectionStart) + 1;
                        int start = OtherTextBox.GetFirstCharIndexFromLine(line);
                        int lenght = OtherTextBox.GetFirstCharIndexFromLine(line + lines - nlines) - start;
                        if (OtherTextBox.TextLength > lenght && start > -1)
                            OtherTextBox.Text = OtherTextBox.Text.Remove(start, lenght);
                        else
                            OtherTextBox.Text = "";
                    }
                    lines = nlines;
                }
            }
            catch { }
        }
        #endregion
    }
}
