﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValueEditor
{
    public class Settings
    {
        public static bool TextBoxSync
        {
            get => MainForm.nameBox.Sync & MainForm.valueBox.Sync;
            set { MainForm.nameBox.Sync = value; MainForm.valueBox.Sync = value; }
        }

        public static bool ShowBlank { get; set; } = true;

        public static bool ShowComment { get; set; } = true;

        public static bool ShowIndent { get; set; } = true;

        public static Encoding Encoding { get; set; } = Encoding.Default;
    }
}
