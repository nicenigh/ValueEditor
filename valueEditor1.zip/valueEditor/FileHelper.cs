﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ValueEditor
{
    public class FileHelper
    {
        public List<Content> Contents { get; } = new List<Content>();
        private string splitPattern = @"^(?<a>\s*?)(?<b>\S+.*\S+?)(?<c>\s*=\s*?)(?<d>\S+.*\S+?)(?<e>\s*?)$";
        private Regex splitRegex;
        private string commentPattern = @"^\s*[/\*|\*/|\*|//+]+.*[\*/]*\s*$";
        private Regex commentRegex;
        public FileHelper()
        {
            splitRegex = new Regex(splitPattern, RegexOptions.Singleline | RegexOptions.Compiled);
            commentRegex = new Regex(commentPattern, RegexOptions.Singleline | RegexOptions.Compiled);
        }
        public void Read(string path)
        {
            var file = new FileInfo(path);
            if (!file.Exists) return;
            using (MemoryMappedFile mfile = MemoryMappedFile.CreateFromFile(path, FileMode.Open))
            {
                using (MemoryMappedViewStream stream = mfile.CreateViewStream())
                {
                    using (StreamReader sr = new StreamReader(stream, Settings.Encoding))
                    {
                        Split(sr);
                    }
                }
            }
        }

        public void Split(StreamReader sr)
        {
            Contents.Clear();
            long lineno = 0;
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                if (line.Contains('\0')) continue;
                if (!string.IsNullOrEmpty(line))
                {
                    try
                    {
                        if (Filter(line))
                        {
                            Contents.Add(new Content { Comment = true, Line = lineno, Name = line });
                        }
                        else
                        {
                            Match match = splitRegex.Match(line);
                            if (match.Success)
                                Contents.Add(new Content
                                {
                                    Line = lineno,
                                    Left = match.Groups.Count > 1 ? match.Groups[1].Value : null,
                                    Name = match.Groups.Count > 2 ? match.Groups[2].Value : null,
                                    Middle = match.Groups.Count > 3 ? match.Groups[3].Value : null,
                                    Value = match.Groups.Count > 4 ? match.Groups[4].Value : null,
                                    Right = match.Groups.Count > 5 ? match.Groups[5].Value : null
                                });
                            else
                                Contents.Add(new Content { Comment = true, Line = lineno, Name = line });
                        }
                    }
                    catch { }
                }
                else
                {
                    Contents.Add(new Content { Blank = true, Line = lineno, Name = line });
                }
                lineno++;
            }
        }

        public bool Filter(string line)
        {
            Match match = commentRegex.Match(line);
            return match.Success;
        }

        public string Merge()
        {
            StringBuilder builder = new StringBuilder();
            foreach (var content in Contents)
            {
                builder.AppendLine(content.ToString());
            }
            return builder.ToString();
        }

        public void Save(string path)
        {
            File.Copy(path, path + ".bak", true);
            FileStream fs = new FileStream(path, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs, Settings.Encoding);
            //开始写入
            sw.Write(Merge());
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }

    }
}
